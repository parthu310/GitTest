let
    config = require('../config'),
    mssql = require('mssql');

function connect(){
    return new mssql.ConnectionPool(config.build.profiles[config.app.env].db);
}

module.exports = {
    "query" : function(dbParams, cbSuccess, cbError){
        var dbConn = connect();
        dbConn.connect().then(function () {
            var dbRequest = new mssql.Request(dbConn);
            
            if("parameter" in dbParams)  {
                for(var input in dbParams.parameter){
                    dbRequest.input(input, dbParams.parameter[input]);
                    console.log("SQL Param [" + input + "] : " + dbParams.parameter[input]);
                }
            }          
            var timer = new Date().getTime();
            dbRequest.query(dbParams.sql).then(function (recordSet) {
                console.log("[SUCCESS | " + (new Date().getTime()-timer) + "] : " + dbParams.sql);
                console.log(recordSet.recordset.length + " records found");
                dbConn.close();
                if(cbSuccess){
                     cbSuccess(recordSet.recordset);
                }else{
                    console.log("No Success Handler for dao.query");
                }
               
               
            }).catch(function (err) {
                console.log("[ERROR | " + (new Date().getTime()-timer) + "] : " + err);
                dbConn.close();
                if(cbError){
                     cbError(err);
                }else{
                     console.log("No Error Handler for dao.query");
                }
               
                
            });
        }).catch(function (err) {
            console.log("[UNKNOWN ERROR]" + err);
            if(cbError){
                    cbError(err);
            }else{
                    console.log("No Error Handler for dao.query");
            }
        });
    },
    "describe" : function(dbParams, cbSuccess, cbError){
        var dbConn = connect();
        dbConn.connect().then(function () {
            var dbRequest = new mssql.Request(dbConn);
            var sql = "SELECT COLUMN_NAME, IS_NULLABLE, DATA_TYPE  FROM information_schema.columns  WHERE TABLE_NAME = @table_name  ORDER BY ordinal_position"
            dbRequest.input("table_name", dbParams.table);

            var timer = new Date().getTime();
            dbRequest.query(sql).then(function (recordSet) {
                console.log("[SUCCESS | " + (new Date().getTime()-timer) + "] : " + sql);
                dbConn.close();
                if(cbSuccess){
                  


                     cbSuccess(recordSet.recordset);
                }else{
                    console.log("No Success Handler for dao.query");
                }
                //console.log(recordSet.recordset);
               
            }).catch(function (err) {
                console.log("[ERROR | " + (new Date().getTime()-timer) + "] : " + err);
                dbConn.close();
                if(cbError){
                     cbError(err);
                }else{
                     console.log("No Error Handler for dao.query");
                }
               
                
            });
        }).catch(function (err) {
            console.log("[UNKNOWN ERROR]" + err);
            if(cbError){
                    cbError(err);
            }else{
                    console.log("No Error Handler for dao.query");
            }
        });
    }  

};
