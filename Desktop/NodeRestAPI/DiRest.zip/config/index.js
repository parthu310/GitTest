module.exports = {
  "app" : {
    "env" : "americas1-123",
    "apiObjects" : {
      "tables" : [
        "sdeData" , "sdeFile", "paceOutboundFileLog"
      ],
      "views" : [
        "vwProjects", "vwPlanningObjects", "vwWorkPlans"
      ]
    }
    
  },
  "build" : {
    "profiles": {
      "americas1-123": {
        "server" : {
            "port" : 1712
        } , 
        "db" : {
            "user": 'sa',
            "password": 'sdasd',
            "server": '138.85.252.123', 
            "database": 'ERISITE_AMERICAS1',
            "port" : 1433
        }
      },
      "americas1-119": {
        "server" : {
            "port" : 1712
        } , 
        "db" : {
            "user": 'sa',
            "password": 'asdasd',
            "server": '138.85.252.119', 
            "database": 'ERISITE_AMERICAS1',
            "port" : 1433
        }
      },
      
    }
  }
} ;
 
