let express = require("express"),
	router = express.Router(),
	dao = require("../../dao"),
    util = require("../../util");
var app = express();

router.get('/data', (req, res, next) => {
	try {
            var pSize = 50;
            if("pageSize" in req.query){
                pSize = req.query.pageSize;
                console.log(util.validate.isNumber(pSize));
                if(!util.validate.isNumber(pSize)){
                    return res.status(400).json(util.response.error({
                        code : 400,
                        data : [{
                            parameter : "pageSize",
                            message : "Not a number"    
                        }]
                    }));
                }
            }
            dao.query({
                "sql" : "SELECT TOP "+pSize +" * FROM [dbo].[sdeData]"
            },function(rs){
                return res.status(200).json(util.response.success({
                    data : rs
                }));
            },function(err){
                return res.status(500).json(util.response.error({
                    code : 500,
                    data : err
                }));
            }); 
            
	} catch (err) {
            return res.status(500).json(util.response.error({
                code : 500,
                data : err
            }));
	}
});

router.get('/data/:id', (req, res, next) => {
	try {
            var id = req.params.id;
            if(!util.validate.isNumber(id)){
                 return res.status(400).json(util.response.error({
                    code : 400,
                     data : [{
                        parameter : "id",
                        message : "Not a number"    
                    }]
                }));
            }
            dao.query({
                "sql" : "SELECT  * FROM [dbo].[sdeData] where id = @id",
                "parameter" :{
                    "id" : id
                }
            },function(rs){
                return res.status(200).json(util.response.success({
                    data : rs
                }));
            },function(err){
                return res.status(500).json(util.response.error({
                    code : 500,
                    data : err
                }));
            }); 
            
	} catch (err) {
            return res.status(500).json(util.response.error({
                code : 500,
                data : err
            }));
	}
});


module.exports = router;