let express = require("express"),
	router = express.Router(),
	dao = require("../../dao"),
    apiDocs = require("./api-docs"),
    util = require("../../util");
var app = express();

router.get('/', (req, res, next) => {
	try {
            var sql = "SELECT COLUMN_NAME, IS_NULLABLE, DATA_TYPE  FROM information_schema.columns  WHERE TABLE_NAME = @table_name  ORDER BY ordinal_position";
            dao.query({
                "sql" : sql,
                "parameter" : {
                    "table_name" : "sdeData"
                }
            },function(rs){
               for(var i=0; i<rs.length ;i++){
                   var prop = {
                       "type" : "string"
                   };
                   if(rs[i]["DATA_TYPE"] == "int"){
                       prop.type = "integer";
                   }
                   var colName = rs[i]["COLUMN_NAME"];
                   
                   apiDocs.definitions["sdeDataRow"].properties[colName] = prop;
                   if(rs[i]["IS_NULLABLE"] == "NO"){
                        apiDocs.definitions["sdeDataRow"].required.push(colName);
                   }
               }
               return res.status(200).json(apiDocs);
            },function(err){
                return res.status(500).json(util.response.error({
                    code : 500,
                    data : err
                }));
            }); 
          
	} catch (err) {
            return res.status(500).json(util.response.error({
                code : 500,
                data : err
            }));
	}
});

module.exports = router;