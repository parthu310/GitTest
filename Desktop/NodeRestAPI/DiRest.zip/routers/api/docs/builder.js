module.exports = {
    "buildPath": function (p) {
        /* p = {
             tag : "Table",
             selectBy : "all" //or name of the column,
             name : table_name //mandatory
         }*/
        var params = JSON.parse(JSON.stringify(p));
        if (!("tag" in params)) params.tag = "tables";
        if (!("selectBy" in params)) params.selectBy = "all";
        var allMode = params.selectBy == "all";

        console.log(params);
        var table = params.name.toLowerCase();
        //console.log(table);
        var selectBy = params.selectBy.toLowerCase();
        //console.log(selectBy);
        var schema = "table_" + table;

        var k = "/api/" + params.tag.toLowerCase() + "/" + params.name + "/";
        if (!allMode) {
            k += "{" + selectBy + "}";
        }
        var r = {
            "get": {
                "tags": [params.tag],
                "summary": (allMode ? "Fetch all from Table " + params.name : "Fetch " + params.name + " by " + params.selectBy),
                "description": (allMode ? "This API fetches all the records from" + params.name + " table." : "This API fetches record from " + params.name + " Table with the specified " + params.selectBy),
                "operationId": table + (allMode ? "params.selectBy" : "BY" + selectBy) + "GET",
                "produces": [
                    "application/json"
                ],
                "parameters": [],
                "responses": {
                    "200": {
                        "description": "Array of Records in sdeData Table",
                        "schema": {
                            "$ref": "#/definitions/" + schema
                        }
                    },
                    "400": {
                        "description": "Bad request due to invalid parameter",
                        "schema": {
                            "$ref": "#/definitions/fault"
                        }
                    },
                    "500": {
                        "description": "Internal Error",
                        "schema": {
                            "$ref": "#/definitions/fault"
                        }
                    }
                }
            }
        };

        //console.log(r.parameters);

        if (allMode) {
            r.get.parameters.push(
                {
                    "name": "pageSize",
                    "in": "query",
                    "description": "the page size of the recordset",
                    "required": false,
                    "type": "integer"
                }
            )
        } else {
            r.get.parameters.push(
                {
                    "name": selectBy,
                    "in": "path",
                    "description": params.selectBy + " of the desired record in " + params.table + " table.",
                    "type": "integer",
                    "required": true
                }
            );
        }


        var defs = [];
        if(allMode){
            defs.push({
                "name" :  "rowOf"+ schema,
                "type": "object",
                "required": [],
                "properties": {}
            });

            
            defs.push({
                "name" : schema,
                "type": "object",
                "required": [
                    "info",
                    "data"
                ],
                "properties": {
                    "data": {
                    "type": "array",
                    "items": {
                        "$ref": "#/definitions/"+  "rowOf"+ schema
                    }
                    },
                    "info": {
                    "$ref": "#/definitions/info"
                    }
                }
            });
            
        }

        var ret = {
            path : k,
            detail : r,
            definitions : defs
        }

        console.log(ret)
        return ret;


    }
};

