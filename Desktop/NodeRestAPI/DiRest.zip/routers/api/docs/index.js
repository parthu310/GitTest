let express = require("express"),
	router = express.Router(),
	dao = require("../../../dao"),
    doc = require("./template"),
    config = require("../../../config"),
    builder = require("./builder"),
    
    util = require("../../../util");
var app = express();

router.get('/', (req, res, next) => {
	try {
            var tableNames  = "'" + config.app.apiObjects.tables.join("' , '") + "'";
            var viewNames  = "'" + config.app.apiObjects.views.join("' , '") + "'";
            var sql = "SELECT 'table' as OBJECT_TYPE,TABLE_NAME, COLUMN_NAME, IS_NULLABLE, DATA_TYPE, ordinal_position  FROM INFORMATION_SCHEMA.COLUMNS  WHERE TABLE_NAME in (" + tableNames + ")   ";
            sql    += "UNION ";
            sql    += "SELECT 'view' as OBJECT_TYPE , c.TABLE_NAME, c.COLUMN_NAME, c.IS_NULLABLE, c.DATA_TYPE, c.ordinal_position from INFORMATION_SCHEMA.VIEWS v join INFORMATION_SCHEMA.COLUMNS c on c.TABLE_SCHEMA = v.TABLE_SCHEMA and c.TABLE_NAME = v.TABLE_NAME and v.TABLE_NAME  in (" + viewNames + ")  ";
            sql    += "ORDER BY OBJECT_TYPE, TABLE_NAME, ordinal_position ";

            //console.log(sql);
            dao.query({
                "sql" : sql
            },function(rs){
                var lastTable = "";
                var lastDef = "";

               // console.log(rs);
                for(var i=0; i<rs.length ;i++){
                    if(lastTable != rs[i]["TABLE_NAME"]){
                        //oh no! its a new table
                        lastTable = rs[i]["TABLE_NAME"];
                        var path = builder.buildPath({
                            tag : (rs[i]["OBJECT_TYPE"]=="view"? "Views" : "Tables"),
                            name : rs[i]["TABLE_NAME"]
                        });
                        doc.paths [path.path] = path.detail;
                        for(var d=0; d<path.definitions.length ;d++){
                            console.log(">>" + d);
                            console.log(path.definitions[d]);
                            console.log(path.definitions[d].name);
                            
                            if(d==0){
                                lastDef = path.definitions[d].name
                            }
                            doc.definitions[path.definitions[d].name] = {
                                "type" : path.definitions[d].type,
                                "required" : path.definitions[d].required,
                                "properties" : path.definitions[d].properties
                            }
                        }
                        console.log("<<<<");
                       // console.log( doc.definitions);
                        path = builder.buildPath({
                            tag : (rs[i]["OBJECT_TYPE"]=="view"? "Views" : "Tables"),
                            name : rs[i]["TABLE_NAME"],
                            selectBy : "id"
                        });
                        doc.paths [path.path] = path.detail;

                    }
                    console.log("=========================");
                    console.log(doc);
                    //its the same old table, do it for the columns
                    var prop = {
                        "type" : "string"
                    };
                    if(rs[i]["DATA_TYPE"] == "int"){
                        prop.type = "integer";
                    }
                    var colName = rs[i]["COLUMN_NAME"];
                    
                    console.log("lastDef"+lastDef)
                    doc.definitions[lastDef].properties[colName] = prop;
                    if(rs[i]["IS_NULLABLE"] == "NO"){
                            doc.definitions[lastDef].required.push(colName);
                    }
                 
               }
               console.log(doc);
               return res.status(200).json(doc);
            },function(err){
                return res.status(500).json(util.response.error({
                    code : 500,
                    data : err
                }));
            }); 
          
	} catch (err) {
            return res.status(500).json(util.response.error({
                code : 500,
                data : err
            }));
	}
});

module.exports = router;




/*SELECT Col.Column_Name from 
    INFORMATION_SCHEMA.TABLE_CONSTRAINTS Tab, 
    INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE Col 
WHERE 
    Col.Constraint_Name = Tab.Constraint_Name
    AND Col.Table_Name = Tab.Table_Name
    AND Constraint_Type = 'PRIMARY KEY'
    AND Col.Table_Name = '<your table name>'*/

