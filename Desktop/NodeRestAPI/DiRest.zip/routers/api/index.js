let express = require('express');
let router = express.Router();


router.get('/', (req, res, next) => {
	
});

module.exports = router;