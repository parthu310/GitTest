let express = require('express');
let app = express();
let router = express.Router();
let sde = require("./sde"); //static
let docs = require("./docs"); //static
let api = require("./api"); 
let apiDocs = require("./api/docs");
let table = require("./api/table");

router.get('/', (req, res) => {
                return res.status(200).json({
                    "msg": "hello"
                });
            });
            
module.exports = (app) => {
    app.use((req, res, next) => {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE');
        res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type,Access-Control-Request-Headers');
        res.setHeader('Access-Control-Allow-Credentials', true);
        console.log('-------------------------------New Request------------------------------------');
        console.log('URL called >> ' + req.path);
        console.log('Method called >> ' + req.method);
        console.log('Request Date & Time >> ' + new Date());
        console.log('Request Body >> ' + JSON.stringify(req.body));
  
        if ('OPTIONS' == req.method) {
            res.send(200);
        }
        else {
             next();
        }
    });

    app.get('/', (req, res) => {
        return res.status(200).json({
            "msg": "hello2"
        });
    });

    app.use('/sde', sde);
    app.use('/docs', docs);
    app.use('/api', api);
    app.use('/api/docs', apiDocs);
    app.use('/api/tables', table);
    app.use('/api/views', table);
    
};
