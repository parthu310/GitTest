var buildBasicResponse = function (){
    return {
        info : {
            "status"    : "success",
            "code"      : 200,
            "time"      : new Date()   
        }
    }
  }

module.exports = {
    response: {
        error: function (errParams) {
            var res = buildBasicResponse();
            res.info.status = "error"
            if("code" in errParams){
                res.info.code = errParams.code
            } 
            if("data" in errParams){
                res.data = errParams.data
            }
            return res;
        },
        success: function (successParams) {
            var res = buildBasicResponse();
            if("data" in successParams){
                res.data = successParams.data
            }
            return res;
        }
    },
    "validate" : {
        "isNumber" : function(str) {
            return !isNaN(str);
        }
    }
};
