const
    routes = require('./routers'),
    express = require('express'),
    bodyParser = require('body-parser'),
    fs = require('fs'),
    path = require('path'),
    config = require('./config'),
    debug = require('debug')('expressdebug:server'),
    dao = require('./dao');

let app = express();

app.use(bodyParser.urlencoded({
    extended: false,
    limit: '20mb'
}));

debug("Hellooooooooooooo DEBUGGING");

app.use(bodyParser.json({ limit: '20mb' }));

routes(app);

app.timeout = 0;
app.listen(config.build.profiles[config.app.env].server.port, () => {
    console.log("Now listening on", config.build.profiles[config.app.env].server.port);
});

app.on("error", (err) => {
    console.log("Caught flash policy server socket error: ");
    console.log(err.stack)
});
















/*
dao.query({
        query : "select 1"
    },
    function(rs){
        console.log(rs);
    },
    function(err){
        console.log(err);
    }
);

dao.query({
        query : "select 2"
    },
    function(rs){
        console.log(rs);
    },
    function(err){
        console.log(err);
    }
)
*/




  /*  var dbConn = new mssql.ConnectionPool(config.build.profiles[config.app.env].db);
    dbConn.connect().then(function () {
        var dbRequest = new mssql.Request(dbConn);
        dbRequest.query("select 1").then(function (recordSet) {
            console.log(recordSet);
             console.log(recordSet.recordsets);
            dbConn.close();
        }).catch(function (err) {
            console.log(err);
            dbConn.close();
        });
    }).catch(function (err) {
        console.log(err);
    });*/