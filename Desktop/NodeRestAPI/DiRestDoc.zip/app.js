const
    express = require('express'),
    bodyParser = require('body-parser'),
    fs = require('fs'),
    path = require('path');
    
let app = express();

app.use(express.static('swagger'));

app.use(bodyParser.urlencoded({
    extended: false,
    limit: '20mb'
}));

app.use(bodyParser.json({ limit: '20mb' }));


app.timeout = 0;
app.listen(1102, () => {
    console.log("Now listening on", 1102);
});

app.on("error", (err) => {
    console.log("Caught flash policy server socket error: ");
    console.log(err.stack)
});
















/*
dao.query({
        query : "select 1"
    },
    function(rs){
        console.log(rs);
    },
    function(err){
        console.log(err);
    }
);

dao.query({
        query : "select 2"
    },
    function(rs){
        console.log(rs);
    },
    function(err){
        console.log(err);
    }
)
*/




  /*  var dbConn = new mssql.ConnectionPool(config.build.profiles[config.app.env].db);
    dbConn.connect().then(function () {
        var dbRequest = new mssql.Request(dbConn);
        dbRequest.query("select 1").then(function (recordSet) {
            console.log(recordSet);
             console.log(recordSet.recordsets);
            dbConn.close();
        }).catch(function (err) {
            console.log(err);
            dbConn.close();
        });
    }).catch(function (err) {
        console.log(err);
    });*/